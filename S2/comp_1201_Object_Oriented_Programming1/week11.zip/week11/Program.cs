﻿namespace week11
{
    class Product
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Quantity { get; set; }
        public double Price { get; set; }

        public override string ToString()
        {
            return $"{ID},{Name},{Quantity},{Price}"; // CSV 格式
        }
    }
        
    class Program
    {
       
        public static Product UseProductCollection()
        {
            Product product = new Product();
            
            Console.Write("Enter product ID: ");
            product.ID = int.Parse(Console.ReadLine());
            
            Console.Write("Enter product name: ");
            product.Name = Console.ReadLine();
            
            Console.Write("Enter product quantity: ");
            product.Quantity = int.Parse(Console.ReadLine());
            
            Console.Write("Enter product price: ");
            product.Price = double.Parse(Console.ReadLine());

            return product;
        }

        public static string Menu()
        {
            Console.WriteLine("----------Sales Records-----------");
            Console.WriteLine("1 - Record new sales to a new file");
            Console.WriteLine("2 - Record new sales to an existing file");
            Console.WriteLine("3 - View existing sales from a file");
            Console.WriteLine("4 - View the list of existing files");
            Console.WriteLine("5 - Replace (update) one sale on an existing file");
            Console.WriteLine("6 - Exit");
            Console.WriteLine("-------------------------");
            Console.Write("Please enter a number: ");
            return Console.ReadLine();
            
            Console.WriteLine("Press any key to clear the console");
            Console.ReadKey();
            Console.Clear();
        }
        

        private static void UpdatingExistingFiles()
        {
            throw new NotImplementedException();
        }

        private static void ViewExistingFiles()
        {
            string[] files = Directory.GetFiles("./"); // Getting a list of the files from the root directory

            foreach (var file in files)
            {
                if (file.Contains("csv")) Console.WriteLine(file);
            }
        }

        private static void ViewExistingSales()
        {
            Console.WriteLine("list of exiting files");
            ViewExistingFiles();
            Console.Write("Enter your desired name for the file (e.g., March): ");
            var fileName = Console.ReadLine() + ".csv";

            if (File.Exists(fileName))
            {
                using (StreamReader sr = new StreamReader(fileName)) // Use StreamReader for reading
                {
                    string line;
                    while ((line = sr.ReadLine()) != null) // Read line by line
                    {
                        string[] output = line.Split(',');
                        Console.WriteLine($"ID: {output[0]}, Name: {output[1]}, Quantity: {output[2]}, Price: {output[3]}");
                    }
                }
            }
            else
            {
                Console.WriteLine("The file does not exist.");
            }
        }

        private static void RecordNewSalesExistingFile()
        {
            throw new NotImplementedException();
        }

        private static void RecordNewSalesNewFile()
        {
            Console.Write("Enter your desired name for the file (e.g., March): ");
            var fileName = Console.ReadLine() + ".csv";

            if (!File.Exists(fileName))
            {
                Console.Write("Enter the number of sales: ");
                var nSale = int.Parse(Console.ReadLine());

                using (StreamWriter sw = new StreamWriter(fileName))
                {
                    for (int i = 0; i < nSale; i++)
                    {
                        Product product = UseProductCollection();
                        sw.WriteLine(product.ToString()); // Ensure correct CSV format
                    }
                } // Automatically closes file
                Console.WriteLine($"File {fileName} created successfully!");
            }
            else
            {
                Console.WriteLine("The file already exists.");
            }
        }

        static void Main(string[] args)
        {
            while (true)
            {
                var choice = Menu(); // Fix for correct class name
                if (choice == "1")
                { RecordNewSalesNewFile(); }
                else if (choice == "2")
                { RecordNewSalesExistingFile(); }
                else if (choice == "3")
                { ViewExistingSales(); }
                else if (choice == "4")
                { ViewExistingFiles(); }
                else if (choice == "5")
                { UpdatingExistingFiles(); }
                else if (choice == "6")
                { Console.WriteLine("Exiting..."); break; }
                else
                { Console.WriteLine("Invalid choice"); }
            }
        }
    }
}
